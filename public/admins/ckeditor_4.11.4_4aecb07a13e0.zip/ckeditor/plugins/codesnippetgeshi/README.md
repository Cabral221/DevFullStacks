Code Snippet GeSHi Plugin
==================================================

For installation and configuration instructions go to the [Code Snippet GeSHi documentation](https://ckeditor.com/docs/ckeditor4/latest/guide/dev_codesnippetgeshi.html) in the [CKEditor Developer's Guide](https://ckeditor.com/docs/ckeditor4/latest/guide.html).

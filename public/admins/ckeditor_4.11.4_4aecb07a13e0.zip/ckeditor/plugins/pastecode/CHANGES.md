Paste code plugin for CKEditor Changelog
====================

## CKEditor 0.1

The first stable release of the Paste code plugin for CKEditor.

See demo here: [Link](http://ollea.ch/media/pastecode/demo.html)

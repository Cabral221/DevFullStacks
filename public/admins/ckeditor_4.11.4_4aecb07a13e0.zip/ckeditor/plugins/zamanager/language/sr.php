<?php
/*
Serbian lang
Ako prevodite ovo na neki vas novi jezil, prevedite sve izmedju navodnika (" text") sve ostalo mora ostati netaknuto.
*/
$BLang_delete = "Obrisi";
$BLang_create= "Kreiraj";
$BLang_save= "Sacuvaj";
$BLang_filename="Fajl";
$BLang_fullPath="Cela Putanja";
$BLang_permission="Pr.Dozvolu";
$BLang_move_dir= "Pomeri Fajl";
$BLang_rename= "Preimenuj";
$BLang_query= "Query";
$BLang_query_prepare= "Startuj Query";
?>

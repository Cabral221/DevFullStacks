EN

Just put zsmanager unziped folder where you want on your site
Corect fill config.php
Than target with your browser zsmanager/index.php
If is all OK you have perfect file manager / editor for all purpose.
